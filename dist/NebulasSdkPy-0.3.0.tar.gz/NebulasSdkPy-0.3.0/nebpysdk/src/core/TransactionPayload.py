# -*- coding: utf-8 -*-
# @Time    : 2018/6/3 下午9:27
# @Author  : GuoXiaoMin
# @File    : TransactionPayload.py
# @Software: PyCharm
class TransactionPayload:

    def to_bytes(self):
        pass

    def gas_count(self):
        pass
